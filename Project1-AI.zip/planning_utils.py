from enum import Enum
from queue import PriorityQueue,LifoQueue
import numpy as np


def create_grid(data, drone_altitude, safety_distance):
    """
    Returns a grid representation of a 2D configuration space
    based on given obstacle data, drone altitude and safety distance
    arguments.
    """

    # minimum and maximum north coordinates
    north_min = np.floor(np.min(data[:, 0] - data[:, 3]))
    north_max = np.ceil(np.max(data[:, 0] + data[:, 3]))
    # minimum and maximum east coordinates
    east_min = np.floor(np.min(data[:, 1] - data[:, 4]))
    east_max = np.ceil(np.max(data[:, 1] + data[:, 4]))
    # given the minimum and maximum coordinates we can
    # calculate the size of the grid.
    north_size = int(np.ceil(north_max - north_min))
    east_size = int(np.ceil(east_max - east_min))
    # Initialize an empty grid
    grid = np.zeros((north_size, east_size))
    # Populate the grid with obstacles
    for i in range(data.shape[0]):
        north, east, alt, d_north, d_east, d_alt = data[i, :]
        if alt + d_alt + safety_distance > drone_altitude:
            obstacle = [
                int(np.clip(north - d_north - safety_distance - north_min, 0, north_size-1)),
                int(np.clip(north + d_north + safety_distance - north_min, 0, north_size-1)),
                int(np.clip(east - d_east - safety_distance - east_min, 0, east_size-1)),
                int(np.clip(east + d_east + safety_distance - east_min, 0, east_size-1)),
            ]
            grid[obstacle[0]:obstacle[1]+1, obstacle[2]:obstacle[3]+1] = 1

    return grid, int(north_min), int(east_min)


# Assume all actions cost the same.
class Action(Enum):
    """
    An action is represented by a 3 element tuple.

    The first 2 values are the delta of the action relative
    to the current grid position. The third and final value
    is the cost of performing the action.
    """

    #I added diagonal mouvements and gave them a cost which is sqrt(2)
    WEST = (0, -1, 1)
    EAST = (0, 1, 1)
    NORTH = (-1, 0, 1)
    SOUTH = (1, 0, 1)
    NW=(-1,-1,np.sqrt(2))
    NE=(-1,1,np.sqrt(2))
    SW=(1,-1,np.sqrt(2))
    SE=(1,1,np.sqrt(2))

    @property
    def cost(self):
        return self.value[2]

    @property
    def delta(self):
        return (self.value[0], self.value[1])


def valid_actions(grid, current_node):
    """
    Returns a list of valid actions given a grid and current node.
    """
    valid_actions = list(Action)
    n, m = grid.shape[0] - 1, grid.shape[1] - 1
    x, y = current_node

    # here I added the process of removing diagonal movements if they were not valid

    if x - 1 < 0 or grid[x - 1, y] == 1:
        valid_actions.remove(Action.NORTH)
        if x-1<0:
            if Action.NW in valid_actions : valid_actions.remove(Action.NW)
            if Action.NE in valid_actions :valid_actions.remove(Action.NE)
        elif x-1>=0 and y-1>=0 and grid[x-1,y-1]==1:
            if Action.NW in valid_actions : valid_actions.remove(Action.NW)
        elif x-1>=0 and y+1<=m and grid[x-1,y+1]==1:
            if Action.NE in valid_actions :valid_actions.remove(Action.NE)
    if x + 1 > n or grid[x + 1, y] == 1:
        valid_actions.remove(Action.SOUTH)
        if x+1>n:
            if Action.SW in valid_actions :valid_actions.remove(Action.SW)
            if Action.SE in valid_actions : valid_actions.remove(Action.SE)
        elif x+1<=n and y-1>=0 and grid[x+1,y-1]==1:
            if Action.SW in valid_actions :valid_actions.remove(Action.SW)
        elif x+1<=n and y+1<=m and grid[x+1,y+1]==1:
            if Action.SE in valid_actions : valid_actions.remove(Action.SE)
    if y - 1 < 0 or grid[x, y - 1] == 1:
        valid_actions.remove(Action.WEST)
        if y-1<0:
            if Action.SW in valid_actions :valid_actions.remove(Action.SW)
            if Action.NW in valid_actions :valid_actions.remove(Action.NW)
        elif x+1<=n and y-1>=0 and  grid[x+1,y-1]==1:
            if Action.SW in valid_actions :valid_actions.remove(Action.SW)
        elif x-1>=0 and y-1>=0 and  grid[x-1,y-1]==1:
            if Action.NW in valid_actions :valid_actions.remove(Action.NW)
    if y + 1 > m or grid[x, y + 1] == 1:
        valid_actions.remove(Action.EAST)
        if y+1>m:
            if Action.NE in valid_actions: valid_actions.remove(Action.NE)
            if Action.SE in valid_actions :valid_actions.remove(Action.SE)
        elif x+1<=n and y+1<=m and  grid[x+1,y+1]==1:
            if Action.SE in valid_actions :valid_actions.remove(Action.SE)
        elif  x-1>=0 and y+1<=m and  grid[x-1,y+1]==1:
            if Action.NE in valid_actions: valid_actions.remove(Action.NE)
    return valid_actions


def a_star(grid, h, start, goal):
    path = []
    path_cost = 0
    queue = PriorityQueue()
    queue.put((0, start))
    visited = set(start)
    branch = {}
    found = False
    i=0
    while not queue.empty():
        item = queue.get()
        current_node = item[1]
        if current_node == start:
            current_cost = 0.0
        else:              
            current_cost = branch[current_node][0]    
        if current_node == goal:        
            print('Found a path.')
            found = True
            break
        else:
            for action in valid_actions(grid, current_node):
                # get the tuple representation
                da = action.delta
                next_node = (current_node[0] + da[0], current_node[1] + da[1])
                branch_cost = current_cost + action.cost
                queue_cost = branch_cost + h(next_node, goal)
                
                if next_node not in visited:                
                    visited.add(next_node)
                    branch[next_node] = (branch_cost, current_node, action)
                    queue.put((queue_cost, next_node))
    if found:
        # retrace steps
        n = goal
        path_cost = branch[n][0]
        path.append(goal)
        while branch[n][1] != start:
            path.append(branch[n][1])
            n = branch[n][1]
        path.append(branch[n][1])
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************') 
    return path[::-1], path_cost


#This is the function that permits me to choose the closest point from the current start in the list of checkpoints
#in the a_starCheckpoints method 
def closest(point,list):
    min=float("inf")
    for l in list:
        b=np.linalg.norm(np.array(point)-np.array(l))
        if b<=min:
            min=b
            res=l
    return res

#QUESTION 1
#This is my implementation of the depth first search algorithm 
#Here is a quick rundown to explain how it works:
#we do depth first search with a visited set because other wise if our goal is not in the good direction(the last action which is SE for me)
#we will inevitably loop infinitely near the border of the grid so I made the visited set to avoid that and still get a solution
#We use a LifoQueue because we just want the last node put in the queue, the rest of the algorithm is really similar to a_star
#except that we don't use any heuristic or path cost as optimality is not of concern
def dfs(grid, start,goal) :
    path = []
    path_cost = 0
    queue = LifoQueue()                                 #We use a LifoQueue here
    queue.put(start)
    branch = {}
    visited=set(start)                                  #We create the visited set
    found = False
    while not queue.empty():
        item = queue.get()
        current_node = item
        if current_node == goal:        
            print('Found a path.')
            found = True
            break
        else:
            for action in valid_actions(grid, current_node):
                # get the tuple representation
                da = action.delta
                next_node = (current_node[0] + da[0], current_node[1] + da[1])
                if next_node not in visited:                
                    visited.add(next_node)               
                    branch[next_node] = (current_node, action)
                    queue.put( next_node)
    if found:
        # retrace steps
        n = goal
        path.append(goal)
        while branch[n][0] != start:
            path.append(branch[n][0])
            n = branch[n][0]
        path.append(branch[n][0])
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************')
    return path[::-1]


#QUESTION 2
#This is my implementation of the iterative deepening a_star algorithm.I opted for a recursive version
#Here is a quick rundown to explain how it works:
#We set the bound as the choosen optmimistic heuristic from the start to the goal first then we run our recursive search algorithm and if we manage
#to get to the goal then we stop if not we loosen the bond by assigning it the value of the minimum value exceeding the previous bound
# and we loop like this until we find a goal or the recursive search returns an infinite distance which would mean that we failed.
#Remark that compared to the other algoritms here we do not retrace the steps at the end as we fill the path
#during the recursive search and also empty it there if we cannot reach the goal
def iterative_astar(grid, h, start, goal) :
    path = []                              #We initialize the path
    path_cost = 0                                 
    branch = {}
    bound=h(start,goal)                    #the first threshold is the value of the heuristic from the start to the goal
    distance=0
    found=False                            #We have not yet found the goal node
    while True:
        distance=rec_search(grid,h,start,goal,0,bound,branch,path)
        if distance < 0:                   #We return -1 one in our recursive search if we find the goal
            print('Found a path.')
            found = True
            break
        elif distance== float("inf"):     #this happens if we are blocked in all ways and have no way of reaching the goal(=no node to expand)
            break
        elif distance==bound: break       #If we have made no progress compared to the previous iteration the we have failed as the bound should loosen every time
        else :bound=distance              #We loosen the threshold for the next iteration
        
    if found:
        n = goal                          #Here we do not retrace steps as the path is constructed in the recursive search
        path_cost = branch[n][0]
        
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************') 
    return path, path_cost

#This is the recursive search algorithm that I use for question 2
def rec_search(grid,h,node, goal,cost,bound,branch,path) :
    if node == goal: return -1                  #If we find the goal we return -1
    current_estimate=cost+h(node,goal)          #Our current estimate for the cost of the path from our current node to the goal
    if current_estimate>bound:                  #If we exceed the bound then we return the estimate
        return current_estimate
    min=float("inf")
    t=10
    for action in valid_actions(grid, node):    #else we expend nodes recursively as long as we don't exceed the bound
        da = action.delta
        next_node =(node[0] + da[0], node[1] + da[1])  
        path.append(next_node)                  #We add the next node to the path for now
        branch[next_node] = (cost + action.cost+h(next_node,goal), node, action)
        t = rec_search(grid, h, next_node, goal,cost + action.cost,bound,branch,path)   #recursive call
        if t < 0:               #if we found the goal in our recursive calls
            return t
        elif t < min:           #if not we take the minimum among the recursive searchs of the neighbouring nodes which is sure to exceed
            min = t             #the threshold if the value returned is >0
        path.pop()              #if we did not find the goal we reempty the path (it will recursively take away all the nodes appened throur recursive calls)
    return min                  #We return our minimum that will be the value to which the bound will be loosened in our iterative_astar
    

#QUESTION 3
#This is my implementation of uniform cost search. We had to reimplement the cost function so i thought about adding a wind parameter,that
#would make the upwind movement more expensive and a downwind one cheaper using scalar product +3/2 to avoid negative values that would
#likely make it behave in an unefficient manner as we'd keep expanding downwind because of negative action costs.By adding 3/2 we make sure that
#even if we start by expanding downwind we will indeed eventually start to explore upwind as the action costs of downwind movements
#will add up.
#Hence, our algorithm here is the same as a_star but without heuristic and with a action cost that depends on the direction of the wind.
#Please remark that because of this choice of implementation(with the wind), the optimality goal changes, it is no longer the shortest path
#but the one with the least resistance encountered caused by the wind(kind of similar to the way seamen try to avoid strong counter currents)
def ucs(grid,start, goal,wind_direction):
    path = []
    path_cost = 0
    queue = PriorityQueue()
    queue.put((0, start))
    visited = set(start)
    branch = {}
    found = False
    i=0
    while not queue.empty():
        item = queue.get()
        current_node = item[1]
        if current_node == start:
            current_cost = 0.0
        else:              
            current_cost = branch[current_node][0]    
        if current_node == goal:        
            print('Found a path.')
            found = True
            break
        else:
            for action in valid_actions(grid, current_node):
                # get the tuple representation
                da = action.delta
                next_node = (current_node[0] + da[0], current_node[1] + da[1])
                branch_cost = current_cost + wind_cost(wind_direction,action)       #calculate the cost of the action using the wind direction
                queue_cost = branch_cost
                
                if next_node not in visited:                
                    visited.add(next_node)
                    branch[next_node] = (branch_cost, current_node, action)
                    queue.put((queue_cost, next_node))
    if found:
        # retrace steps
        n = goal
        path_cost = branch[n][0]
        path.append(goal)
        while branch[n][1] != start:
            path.append(branch[n][1])
            n = branch[n][1]
        path.append(branch[n][1])
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************') 
    return path[::-1], path_cost

#QUESTION 3
#This is the function to calculate the action cost in the ucs algorithm
def wind_cost(action,node_action):
    return np.dot(action.delta,node_action.delta)+3/2



#QUESTION 4
# This is the other heuristic that I implemented, the Manhatten distance was subjected in the description of the project but since I
#added diagonal movement it would not have been valid as an heuristic. Instead I choose to opt for the smallest possible path to go
#from one vertex to its opposit in a rectangle. It is indeed optimistic as we operate in a grid so the path can never be shorter, only equal.
#Concerning its use in a_star we observe that since a lot of paths can have this length(except if we are in a square(i.e diagonal path)
# or on a straight line) so the a_star is less likely to "stick" to the line between the start and the goal as when we use the euclidian
#distance as heuristic. Also, I realized that my iterative a_star is more efficient time-wise using this heuristic as it is less strict as
#a threshold and so we can have a thresold that permits to find a solution faster. 
def smallest_cost(position,goal_position):
    return min(abs(position[0]-goal_position[0]),abs(position[1]-goal_position[1]))*(np.sqrt(2)-1)+max(abs(position[0]-goal_position[0]),abs(position[1]-goal_position[1]))


#QUESTION 6
#This is my implementation of the a_star with checkpoints problem ,in the question it is asked only three but I made a version
#that works with any number of checkpoints.
#Here is a quick rundown to explain how it works:
#We pass a list of any number of checkpoints to go through then we start from the start of the path and go to the closest
#point in the checkpoints list using the closest function implemented above , we then find the path to this closest point
#using the a_star based algorithm and once we reach it we put it as current_start and repeat the process until we reach the true
#goal.Moreover we had to separate the branch by portion of the full path to avoid a redundancy of points which would cause infinite looping
#during the reconstruction of the path.
def a_starCheckpoints(grid, h, start,checkpoints, goal):
    path = []                                             #initialize the path
    path_cost = 0
    queue = PriorityQueue()                               #We use a priority queue because it is an a_star algorithm
    branch = {}
    found = False                                         #We have not found the final goal
    current_start=start                                   #We initialize our current start
    goForGoal=False                                       #We are not yet computing the path to reach the final goal
    num_cp=1                                              #Number of checkpoints encountered
    queue.put((0, current_start))
    passed=[]
    while not goForGoal:                                  #Outer loop loops until we are searching for the final goal
        if not(len(checkpoints)==0):                      #As long as we have checkpoints to visit
            current_goal=closest(current_start,checkpoints)     #We update the current goal
            checkpoints.remove(current_goal)                    #And remove it from the list of checkpoints that we have to visit
            visited=set(current_start)                          #we initialize the visited set with our current start
            passed.append(current_start)                        #we add our current start to the list of checkpoints we passed
            print("yo")
        else:                                                   #If not
            goForGoal=True                                      #Then we are looking for the final goal
            current_goal=goal                                   #so we set it as our current goal
            visited=set(current_start)                          #we initialize the visited set with our current start
            passed.append(current_start)                        #we add our current start to the list of checkpoints we passed
            print("yololo")
        while not queue.empty():
            item = queue.get()
            current_node = item[1]                              #same as classic a_star
            if current_node == current_start:
                current_cost = 0.0
            else:              
                current_cost = branch[num_cp,current_node][0]    
            if current_node== current_goal:                     #if we reach our current goal
                print("Found checkpoint:",num_cp,":",current_goal)               #We display some feedback 
                num_cp=num_cp+1
                current_start=current_goal                      #our new current start is our previous current goal(we will concatenate the paths)
                queue=PriorityQueue()                           #We empty the priority queue
                queue.put((0, current_start))                   #and put our new current start in
                if goForGoal==True:                             #Moreover if we actually reached the final goal
                    print('Found a path.')
                    found = True                                #We have finished so we break out of the loop
                    break
                break
            else:                                               #path searching as long as we have not found current goal(classic a_star)
                for action in valid_actions(grid, current_node):
                    # get the tuple representation
                    da = action.delta
                    next_node = (current_node[0] + da[0], current_node[1] + da[1])
                    branch_cost = current_cost + action.cost
                    queue_cost = branch_cost + h(next_node, current_goal)
                    
                    if next_node not in visited:                
                        visited.add(next_node)
                        branch[num_cp,next_node] = (branch_cost, current_node, action)
                        if next_node==(319,466):print(num_cp,branch[num_cp,next_node])
                        queue.put((queue_cost, next_node))
    if found:
        # retrace steps
        n = goal
        i=4
        path_cost = branch[i,n][0]
        path.append(goal)
        while not(len(passed)==0):
            objective=passed.pop()
            while branch[i,n][1] != objective:              #We reconstruct the path going from the latest checkpoint passed until the
                path.append(branch[i,n][1])                 #original start.This is to avoid a conflict if we ever passed multiple times
                print(h(branch[i,n][1],objective))
                n = branch[i,n][1]                          #through the original start node in which case the branch[n][1] != start
            path.append(objective)                          #would not work as it would stop the process before having the full path
            n=objective
            i=i-1
        path.append(branch[1,n][1])                         
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************') 
    return path[::-1], path_cost


def heuristic(position, goal_position):
    return np.linalg.norm(np.array(position) - np.array(goal_position))
import numpy as np
import matplotlib.pyplot as plt
from bresenham import bresenham
from scipy.spatial import Voronoi
import networkx as nx
from queue import Queue
filename = 'colliders.csv'
data = np.loadtxt(filename, delimiter=',', dtype='Float64', skiprows=2)
# Here you'll modify the `create_grid()` method from a previous exercise
# In this new function you'll record obstacle centres and
# create a Voronoi graph around those points
def create_grid_and_edges(data, drone_altitude, safety_distance):
    """
    Returns a grid representation of a 2D configuration space
    along with Voronoi graph edges given obstacle data and the
    drone's altitude.
    """
    # minimum and maximum north coordinatesnorth_min = np.floor(np.min(data[:, 0] - data[:, 3]))
    north_min = np.floor(np.min(data[:, 0] - data[:, 3]))
    north_max = np.ceil(np.max(data[:, 0] + data[:, 3]))
    # minimum and maximum east coordinates
    east_min = np.floor(np.min(data[:, 1] - data[:, 4]))
    east_max = np.ceil(np.max(data[:, 1] + data[:, 4]))
    # given the minimum and maximum coordinates we can
    # calculate the size of the grid.
    north_size = int(np.ceil((north_max - north_min)))
    east_size = int(np.ceil((east_max - east_min)))
    # Initialize an empty grid
    grid = np.zeros((north_size, east_size))
    # Center offset for grid
    north_min_center = np.min(data[:, 0])
    east_min_center = np.min(data[:, 1])
    # Define a list to hold Voronoi points
    points = []
    # Populate the grid with obstacles
    for i in range(data.shape[0]):
        north, east, alt, d_north, d_east, d_alt = data[i, :]
        if alt + d_alt + safety_distance > drone_altitude:
            obstacle = [
            int(north - d_north - safety_distance - north_min_center),
            int(north + d_north + safety_distance - north_min_center),
            int(east - d_east - safety_distance - east_min_center),
            int(east + d_east + safety_distance - east_min_center),
            ]
            grid[obstacle[0]:obstacle[1], obstacle[2]:obstacle[3]] = 1
    # add center of obstacles to points list
            points.append([north - north_min, east - east_min])
    # TODO: create a voronoi graph based on
    # location of obstacle centres
    graph = Voronoi(points)
    # TODO: check each edge from graph.ridge_vertices for collision
    edges = []
    for edge in graph.ridge_vertices:
        point1 = graph.vertices[edge[0]]
        point2 = graph.vertices[edge[1]]
        cells = list(bresenham(int(point1[0]), int(point1[1]), int(point2[0]), int(point2[1])))
        infeasible = False
        for cell in cells:
            if np.amin(cell) < 0 or cell[0] >= grid.shape[0] or cell[1] >=grid.shape[1]:
                infeasible = True
                break
            if grid[cell[0], cell[1]] == 1:
                infeasible = True
                break
        if infeasible == False:
            point1 = (point1[0], point1[1])
            point2 = (point2[0], point2[1])
            edges.append((point1,point2))
    return grid, edges

# Define a flying altitude (feel free to change this)
"""
drone_altitude = 5
safety_distance = 3
grid, edges = create_grid_and_edges(data, drone_altitude, safety_distance)
print('Found %5d edges' % len(edges))

# equivalent to
# plt.imshow(np.flip(grid, 0))
# Plot it up!
plt.imshow(grid, origin='lower', cmap='Greys')
# Stepping through each edge
for e in edges:
    p1 = e[0]
    p2 = e[1]
    plt.plot([p1[1], p2[1]], [p1[0], p2[0]], 'b-')
plt.xlabel('EAST')
plt.ylabel('NORTH')
plt.show()
"""
def takeSecond(elem):
    return elem[1]




#QUESTION 5
#The two following functions are my answer to the breadth first search algorithm using the graph
#the first fnction is the add_start and goal function that adds our start and goal to the graph so that we can the explore it to construct
#our path
#To sum it up we will the start node to the graph and link it to the closest unblocked(no obstacle) node in the graph and same for the goal
def add_start_and_goal(start,goal,edges,grid):
    dist_start={(v,np.linalg.norm(np.array(start)-np.array(v))) for edge in edges for v in edge}
    dist_goal={(v,np.linalg.norm(np.array(goal)-np.array(v))) for edge in edges for v in edge}
    dist_start=list(dist_start)
    dist_start.sort(key=takeSecond)
    dist_goal=list(dist_goal)
    dist_goal.sort(key=takeSecond)
    while not len(dist_start)==0:
        cells = list(bresenham(int(start[0]), int(start[1]), int(dist_start[0][0][0]), int(dist_start[0][0][1])))
        infeasible = False
        for cell in cells:
            if np.amin(cell) < 0 or cell[0] >= grid.shape[0] or cell[1] >=grid.shape[1]:
                infeasible = True
                break
            if grid[cell[0], cell[1]] == 1:
                infeasible = True
                break
        if infeasible == False:
            edges.append((start,dist_start[0][0]))
            break
        else:
            dist_start.pop(0)
    while not len(dist_goal)==0:
        cells = list(bresenham(int(goal[0]), int(goal[1]), int(dist_goal[0][0][0]), int(dist_goal[0][0][1])))
        infeasible = False
        for cell in cells:
            if np.amin(cell) < 0 or cell[0] >= grid.shape[0] or cell[1] >=grid.shape[1]:
                infeasible = True
                break
            if grid[cell[0], cell[1]] == 1:
                infeasible = True
                break
        if infeasible == False:
            edges.append((goal,dist_goal[0][0]))
            return
        else:
            dist_goal.pop(0)


#This is my breadth first search algorithm
def bfs(grid,edges,start,goal):
    add_start_and_goal(start,goal,edges,grid)           #We add the start and the goal to the graph
    G=nx.Graph()                                        #We create the networkX graph
    for edge in edges:
        G.add_nodes_from([(int(edge[0][0]),int(edge[0][1])),(int(edge[1][0]),int(edge[1][1]))])        #We fill the neworkX graph
        G.add_edge((int(edge[0][0]),int(edge[0][1])),(int(edge[1][0]),int(edge[1][1])))
    path=[]
    queue=Queue()
    queue.put(start)
    branch={}
    found=False
    visited=set(start)
    i=0
    while (not found) and (not queue.empty()):
        item=queue.get()
        i=i+1
        if item==goal:
            print("Found a path.")
            found=True
            break
        for edge in G.edges(item):                   #We visit all edges that stem from our current item(node)
            if edge[1] not in visited:
                visited.add(edge[1])
                branch[edge[1]] = item
                queue.put(edge[1])
    if found:
        # retrace steps
        n = goal
        path.append(goal)
        while branch[n] != start:
            path.append(branch[n])
            n = branch[n]
        path.append(branch[n])
    else:
        print('**********************')
        print('Failed to find a path!')
        print('**********************') 
    return path[::-1]
